/*
Montserrat Garcia Galiano Ramirez
0004657654
8/08/15
SDI 1508-02
Creating Variables and Output
 */

alert ("Beware! Horse lovers only!");

var numberOfHorses = 4; // Number variable

var loveHorses = true; // Boolean variable

var horseType = "Jumping"; // String variable

var yearsRiding= 17 // Number variable

var myNickname= "Montse"; // String variable

var myHorses = ["Wonsay", "Ikke", "Francesca", "Gaona"]; // Array

console.log("What do you like being called?", myNickname);
console.log("Number of horses=", numberOfHorses);
console.log("Does Montse love horses?", loveHorses);
console.log("What do you do with your horses?", horseType);
console.log("Years riding=", yearsRiding);
console.log("What are your horses' names?", myHorses);
